package com.example.premlea;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PremleaApplicationTests {

	@Test
	void contextLoads() {
	}

}
