package com.example.premlea;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PremleaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PremleaApplication.class, args);
	}

}
